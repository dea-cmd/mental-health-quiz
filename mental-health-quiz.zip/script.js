const questions = [
  {
    q: "Apa yang kamu rasakan saat bangun tadi pagi?",
    a: [
      { text: "Tenang dan siap memulai hari", score: 1 },
      { text: "Biasa aja", score: 2 },
      { text: "Cemas dan malas", score: 3 }
    ]
  },
  {
    q: "Seberapa sering kamu merasa lelah secara emosional?",
    a: [
      { text: "Jarang", score: 1 },
      { text: "Kadang-kadang", score: 2 },
      { text: "Sering", score: 3 }
    ]
  },
  {
    q: "Bagaimana tidurmu akhir-akhir ini?",
    a: [
      { text: "Cukup & nyenyak", score: 1 },
      { text: "Kadang kurang", score: 2 },
      { text: "Sering susah tidur", score: 3 }
    ]
  },
  {
    q: "Kapan terakhir kamu melakukan hal yang kamu sukai?",
    a: [
      { text: "Hari ini / kemarin", score: 1 },
      { text: "Minggu ini", score: 2 },
      { text: "Sudah lupa", score: 3 }
    ]
  },
  {
    q: "Apakah kamu merasa punya support system (keluarga/teman)?",
    a: [
      { text: "Iya, jelas", score: 1 },
      { text: "Kadang merasa sendiri", score: 2 },
      { text: "Tidak punya atau merasa kesepian", score: 3 }
    ]
  }
];

let current = 0;
let score = 0;
const container = document.getElementById("quiz-container");
const resultBox = document.getElementById("result-box");

function showQuestion() {
  const q = questions[current];
  let html = `<div class="question"><h2>${q.q}</h2>`;
  q.a.forEach(option => {
    html += `<button onclick="choose(${option.score})">${option.text}</button>`;
  });
  html += `</div>`;
  container.innerHTML = html;
}

function choose(s) {
  score += s;
  current++;
  if (current < questions.length) {
    showQuestion();
  } else {
    showResult();
  }
}

function showResult() {
  container.innerHTML = "";
  resultBox.style.display = "block";
  let message = "";
  if (score <= 7) {
    message = "💚 Kamu dalam kondisi baik. Tetap jaga dirimu ya!";
  } else if (score <= 11) {
    message = "💛 Kamu butuh rehat. Coba tarik napas dan ambil waktu untuk dirimu sendiri.";
  } else {
    message = "❤️ Sepertinya kamu perlu bicara dengan seseorang. Jangan ragu untuk cari bantuan, ya!";
  }
  resultBox.innerHTML = `<h2>Hasil Tes</h2><p>${message}</p>`;
}

showQuestion();
